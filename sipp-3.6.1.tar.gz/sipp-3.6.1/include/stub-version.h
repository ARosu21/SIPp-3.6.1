#define SIPP_VERSION "v3.6.x"
#if 1 /* set to 0 to bypass the "#error" below */
#error "\
  This is a stub version.h. You should not use this fake version number, \
but a git-tagged version instead. \
  \
  You should download the proper .tar.gz which includes a proper \
version.h or clone the SIPp repository using git."
#endif
